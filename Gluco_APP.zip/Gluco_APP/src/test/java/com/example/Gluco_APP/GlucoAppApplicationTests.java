package com.example.Gluco_APP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlucoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
